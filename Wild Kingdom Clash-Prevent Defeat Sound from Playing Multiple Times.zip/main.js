import { GameManager } from './GameManager.js';

window.game = new GameManager();
console.log('Animal Kingdom: Clash initialized!');
